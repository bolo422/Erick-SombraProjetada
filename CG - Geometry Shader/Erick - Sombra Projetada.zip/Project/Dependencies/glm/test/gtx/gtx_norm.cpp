#define GLM_ENABLE_EXPERIMENTAL
#include <glm/gtx/norm.hpp>

int main()
{
	int Error(0);

	return Error;
}
